import { useState } from 'react';

export default function App() {
  const [activeTab, setActiveTab] = useState('treinos');

  const Card = ({ children, className = '' }) => (
    <div className={`rounded-xl shadow p-4 mb-4 bg-white border ${className}`}>{children}</div>
  );

  return (
    <div className="min-h-screen text-[#0A2647] p-4 md:p-10 font-sans">
      <header className="flex flex-col md:flex-row justify-between items-center py-4 border-b border-[#2C74B3]">
        <h1 className="text-2xl font-bold text-[#0A2647] mb-2 md:mb-0">Endurance On</h1>
        <nav className="space-x-4">
          <button onClick={() => setActiveTab('treinos')} className="hover:text-[#F99707]">Treinos</button>
          <button onClick={() => setActiveTab('parceiros')} className="hover:text-[#F99707]">Parceiros</button>
          <button onClick={() => setActiveTab('cupons')} className="hover:text-[#F99707]">Cupons</button>
          <button onClick={() => setActiveTab('galeria')} className="hover:text-[#F99707]">Galeria</button>
          <button onClick={() => setActiveTab('novidades')} className="hover:text-[#F99707]">Novidades</button>
        </nav>
      </header>

      <main className="mt-6">
        {activeTab === 'treinos' && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Treinos Coletivos</h2>
            <Card className="border-[#2C74B3]">
              <p>Explore nossos treinos para todos os níveis e objetivos.</p>
            </Card>
          </section>
        )}
        {activeTab === 'parceiros' && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Área de Parceiros</h2>
            <Card className="border-[#2C74B3]">
              <p>Conheça quem está com a gente nessa jornada.</p>
            </Card>
          </section>
        )}
        {activeTab === 'cupons' && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Cupons de Desconto</h2>
            <Card className="border-[#F99707]">
              <p>Aproveite descontos exclusivos para membros!</p>
            </Card>
          </section>
        )}
        {activeTab === 'galeria' && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Galeria</h2>
            <Card className="border-[#2C74B3]">
              <p>Veja fotos e vídeos dos nossos treinos e eventos.</p>
            </Card>
          </section>
        )}
        {activeTab === 'novidades' && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Novidades</h2>
            <Card className="border-[#2C74B3]">
              <p>Fique por dentro do que está rolando!</p>
            </Card>
          </section>
        )}
      </main>

      <footer className="mt-10 border-t pt-4 text-center text-sm text-[#0A2647]">
        © {new Date().getFullYear()} Endurance On. Todos os direitos reservados.
      </footer>
    </div>
  );
}
