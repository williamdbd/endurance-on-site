import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("treinos");

  return (
    <div className="min-h-screen bg-[#f7f7f7] text-[#0A2647] p-4 md:p-10 font-sans">
      <header className="flex justify-between items-center py-4 border-b border-[#2C74B3]">
        <h1 className="text-2xl font-bold text-[#0A2647]">Endurance On</h1>
        <nav className="space-x-4">
          <button onClick={() => setActiveTab("treinos")} className="hover:text-[#F99707]">Treinos</button>
          <button onClick={() => setActiveTab("parceiros")} className="hover:text-[#F99707]">Parceiros</button>
          <button onClick={() => setActiveTab("cupons")} className="hover:text-[#F99707]">Cupons</button>
          <button onClick={() => setActiveTab("galeria")} className="hover:text-[#F99707]">Galeria</button>
          <button onClick={() => setActiveTab("novidades")} className="hover:text-[#F99707]">Novidades</button>
        </nav>
      </header>

      <main className="mt-6">
        {activeTab === "treinos" && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Treinos Coletivos</h2>
            <Card className="bg-white border border-[#2C74B3]">
              <CardContent>
                <p>Explore nossos treinos para todos os níveis e objetivos.</p>
              </CardContent>
            </Card>
          </section>
        )}

        {activeTab === "parceiros" && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Área de Parceiros</h2>
            <Card className="bg-white border border-[#2C74B3]">
              <CardContent>
                <p>Conheça quem está com a gente nessa jornada.</p>
              </CardContent>
            </Card>
          </section>
        )}

        {activeTab === "cupons" && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Cupons de Desconto</h2>
            <Card className="bg-white border border-[#F99707]">
              <CardContent>
                <p>Aproveite descontos exclusivos para membros!</p>
              </CardContent>
            </Card>
          </section>
        )}

        {activeTab === "galeria" && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Galeria</h2>
            <Card className="bg-white border border-[#2C74B3]">
              <CardContent>
                <p>Veja fotos e vídeos dos nossos treinos e eventos.</p>
              </CardContent>
            </Card>
          </section>
        )}

        {activeTab === "novidades" && (
          <section>
            <h2 className="text-xl font-semibold mb-4 text-[#2C74B3]">Novidades</h2>
            <Card className="bg-white border border-[#2C74B3]">
              <CardContent>
                <p>Fique por dentro do que está rolando!</p>
              </CardContent>
            </Card>
          </section>
        )}
      </main>

      <footer className="mt-10 border-t pt-4 text-center text-sm text-[#0A2647]">
        © {new Date().getFullYear()} Endurance On. Todos os direitos reservados.
      </footer>
    </div>
  );
}
